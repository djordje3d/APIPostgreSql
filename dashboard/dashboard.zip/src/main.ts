import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './index.css'
import './icom/style.css'
import './styles/zindex.css'

const app = createApp(App)
app.use(router)
app.mount('#app')
