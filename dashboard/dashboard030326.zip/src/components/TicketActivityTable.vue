<template>
  <div class="rounded-lg bg-white shadow ring-1 ring-gray-200">
    <div class="border-b border-gray-200 px-4 py-3">
      <h2 class="text-lg font-semibold text-gray-900">Ticket activity (last 10)</h2>
    </div>
    <div class="overflow-x-auto">
      <!-- Error: retry -->
      <div
        v-if="error"
        class="flex flex-col items-center justify-center gap-2 px-4 py-8 text-center"
        role="alert"
      >
        <button
          type="button"
          class="text-red-600 underline hover:text-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-1"
          @click="retry"
        >
          Failed to fetch data, click here to retry
        </button>
      </div>

      <!-- Loading (no data yet) -->
      <div
        v-else-if="loading"
        class="flex flex-col items-center justify-center gap-3 px-4 py-12 text-gray-500"
        aria-busy="true"
        aria-live="polite"
      >
        <span class="icon-spinner11 inline-block text-2xl animate-spin" aria-hidden="true"></span>
        <span>loading data...</span>
      </div>

      <!-- Idle -->
      <div
        v-else-if="!hasLoadedOnce && !refreshing"
        class="px-4 py-12 text-center text-gray-400"
      >
        —
      </div>

      <!-- Content with refreshing overlay -->
      <div v-else class="relative min-h-[120px]">
        <div
          v-if="refreshing"
          class="absolute inset-0 z-10 flex items-center justify-center bg-white/70"
          aria-busy="true"
          aria-label="Refreshing"
        >
          <span class="icon-spinner11 inline-block text-3xl animate-spin text-gray-500" aria-hidden="true"></span>
        </div>

        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Entry time</th>
              <th class="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Exit time</th>
              <th class="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Spot</th>
              <th class="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Plate</th>
              <th class="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Status</th>
              <th class="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Payment</th>
              <th class="px-4 py-2 text-right text-xs font-medium uppercase text-gray-500">Fee</th>
              <th class="px-4 py-2 text-right text-xs font-medium uppercase text-gray-500">Rest to pay</th>
              <th class="px-4 py-2 text-right text-xs font-medium uppercase text-gray-500">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200 bg-white">
          <tr v-for="t in (tickets || [])" :key="t.id" class="hover:bg-gray-50">
            <td class="whitespace-nowrap px-4 py-3 text-sm text-gray-700">{{ formatTime(t.entry_time) }}</td>
            <td class="whitespace-nowrap px-4 py-3 text-sm text-gray-700">{{ formatTime(t.exit_time) }}</td>
            <td class="px-4 py-3 text-sm text-gray-700">{{ t.spot_code ?? '–' }}</td>
            <td class="px-4 py-3 text-sm font-medium text-gray-900">{{ t.licence_plate ?? '–' }}</td>
            <td class="px-4 py-3">
              <span
                :class="[
                  'rounded px-2 py-0.5 text-xs font-medium',
                  t.ticket_state === 'OPEN' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800',
                ]"
              >
                {{ t.ticket_state }}
              </span>
            </td>
            <td class="px-4 py-3">
              <span
                :class="[
                  'rounded px-2 py-0.5 text-xs font-medium',
                  t.payment_status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : t.payment_status === 'PARTIALLY_PAID' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700',
                ]"
              >
                {{ t.payment_status ?? '–' }}
              </span>
            </td>
            <td class="whitespace-nowrap px-4 py-3 text-right text-sm text-gray-700">{{ formatMoney(t.fee) }}</td>
            <td class="whitespace-nowrap px-4 py-3 text-right text-sm font-medium" :class="restToPayClass(t)">{{ formatRestToPay(t) }}</td>
            <td class="whitespace-nowrap px-4 py-3 text-right text-sm">
              <button
                type="button"
                class="text-slate-600 hover:text-slate-900"
                title="View ticket"
                @click="viewTicket(t)"
              >
                View
              </button>
              <template v-if="t.ticket_state === 'OPEN'">
                <button
                  type="button"
                  class="ml-2 text-amber-600 hover:text-amber-800"
                  title="Close ticket"
                  @click="closeTicket(t.id)"
                >
                  Close
                </button>
              </template>
              <template v-else-if="t.ticket_state === 'CLOSED' && t.payment_status !== 'PAID'">
                <button
                  type="button"
                  class="ml-2 text-emerald-600 hover:text-emerald-800"
                  title="Go to payment"
                  @click="openPayment(t)"
                >
                  Payment
                </button>
              </template>
            </td>
          </tr>
            <tr v-if="(tickets || []).length === 0">
              <td colspan="9" class="px-4 py-6 text-center text-gray-500">No tickets</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <PaymentModal
      v-if="paymentTicket"
      :ticket-id="paymentTicket.id"
      :fee="paymentTicket.fee"
      :garage-name="paymentTicket.garage_name ?? undefined"
      @close="closePaymentModal"
      @done="onPaymentDone"
    />
    <div v-if="viewingTicket" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50" @click.self="viewingTicket = null">
      <div class="max-h-[90vh] w-full max-w-md overflow-auto rounded-lg bg-white p-6 shadow-xl">
        <div class="mb-4 flex justify-between">
          <h3 class="text-lg font-semibold">Ticket #{{ viewingTicket.id }}</h3>
          <button type="button" class="text-gray-500 hover:text-gray-700" @click="viewingTicket = null">&times;</button>
        </div>
        <dl class="space-y-2 text-sm">
          <div><dt class="text-gray-500">Entry</dt><dd>{{ formatTime(viewingTicket.entry_time) }}</dd></div>
          <div><dt class="text-gray-500">Exit</dt><dd>{{ formatTime(viewingTicket.exit_time) || '–' }}</dd></div>
          <div><dt class="text-gray-500">Spot</dt><dd>{{ viewingTicket.spot_code ?? '–' }}</dd></div>
          <div><dt class="text-gray-500">Plate</dt><dd>{{ viewingTicket.licence_plate ?? '–' }}</dd></div>
          <div><dt class="text-gray-500">State</dt><dd>{{ viewingTicket.ticket_state }}</dd></div>
          <div><dt class="text-gray-500">Payment</dt><dd>{{ viewingTicket.payment_status }}</dd></div>
          <div><dt class="text-gray-500">Fee</dt><dd>{{ formatMoney(viewingTicket.fee) }}</dd></div>
        </dl>
        <button
          v-if="viewingTicket.ticket_state === 'CLOSED' && viewingTicket.payment_status !== 'PAID'"
          type="button"
          class="mt-4 rounded bg-emerald-600 px-3 py-1.5 text-white hover:bg-emerald-700"
          @click="openPayment(viewingTicket); viewingTicket = null"
        >
          Go to payment
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'
import { listTicketsDashboard, ticketExit } from '../api/tickets'
import type { TicketDashboardRow } from '../api/tickets'
import { getPaymentsByTicket } from '../api/payments'
import PaymentModal from './PaymentModal.vue'

const props = withDefaults(
  defineProps<{ garageId?: number | null }>(),
  { garageId: undefined }
)

const loading = ref(false)
const refreshing = ref(false)
const error = ref(false)
const hasLoadedOnce = ref(false)
const tickets = ref<TicketDashboardRow[]>([])
const viewingTicket = ref<TicketDashboardRow | null>(null)
const paymentTicket = ref<TicketDashboardRow | null>(null)
/** Rest to pay (fee - total paid) per ticket id, for table display. Fetched when tickets load. */
const restToPayMap = ref<Record<number, number>>({})

function formatTime(s: string | null) {
  if (!s) return '–'
  try {
    const d = new Date(s)
    return d.toLocaleString()
  } catch {
    return s
  }
}

function formatMoney(value: string | null | undefined): string {
  if (value == null || value === '') return '–'
  const n = parseFloat(String(value))
  if (Number.isNaN(n)) return '–'
  return new Intl.NumberFormat('sr-RS', { style: 'decimal', maximumFractionDigits: 0 }).format(n) + ' RSD'
}

function formatRestToPay(t: TicketDashboardRow): string {
  if (t.ticket_state === 'OPEN') return '–'
  if (t.payment_status === 'PAID') return '0 RSD'
  const rest = restToPayMap.value[t.id]
  if (rest !== undefined) return formatMoney(String(rest))
  // Still loading rest-to-pay for this ticket
  if (t.ticket_state === 'CLOSED' && t.payment_status !== 'PAID') return '…'
  return '–'
}

function restToPayClass(t: TicketDashboardRow): string {
  if (t.payment_status === 'PAID' || t.ticket_state === 'OPEN') return 'text-gray-500'
  return 'text-amber-700'
}

async function fetchRestToPayForTickets(items: TicketDashboardRow[]) {
  const needRest = items.filter(
    (t) => t.ticket_state !== 'OPEN' && t.payment_status !== 'PAID'
  )
  if (needRest.length === 0) {
    restToPayMap.value = {}
    return
  }
  const map: Record<number, number> = {}
  await Promise.all(
    needRest.map(async (t) => {
      const feeNum =
        t.fee != null && t.fee !== ''
          ? parseFloat(String(t.fee))
          : 0
      const fee = Number.isNaN(feeNum) ? 0 : feeNum
      try {
        const res = await getPaymentsByTicket(t.id, { limit: 500 })
        const totalPaid = res.data.items.reduce(
          (s, p) => s + parseFloat(p.amount),
          0
        )
        map[t.id] = Math.max(0, fee - totalPaid)
      } catch {
        map[t.id] = fee
      }
    })
  )
  restToPayMap.value = { ...restToPayMap.value, ...map }
}

async function fetch() {
  const hasData = tickets.value.length > 0 || hasLoadedOnce.value
  if (!hasData) {
    loading.value = true
    error.value = false
    restToPayMap.value = {}
  } else {
    refreshing.value = true
  }
  try {
    const res = await listTicketsDashboard({
      ...(props.garageId != null ? { garage_id: props.garageId } : {}),
      limit: 10,
      offset: 0,
    })
    tickets.value = res.data.items
    await fetchRestToPayForTickets(tickets.value)
    hasLoadedOnce.value = true
    error.value = false
  } catch {
    error.value = true
    if (!hasData) {
      tickets.value = []
      restToPayMap.value = {}
    }
  } finally {
    loading.value = false
    refreshing.value = false
  }
}

function retry() {
  error.value = false
  fetch()
}

function viewTicket(t: TicketDashboardRow) {
  viewingTicket.value = t
}

function openPayment(t: TicketDashboardRow) {
  paymentTicket.value = t
}

async function closeTicket(id: number) {
  try {
    await ticketExit(id)
    await fetch()
    window.dispatchEvent(new CustomEvent('dashboard-refresh'))
  } catch {
    // could show toast
  }
}

// TODO: make it work (the modal is not closing)
function closePaymentModal() {
  nextTick(() => {
    paymentTicket.value = null
  })
}

function onPaymentDone() {
  nextTick(() => {
    paymentTicket.value = null
    fetch()
    window.dispatchEvent(new CustomEvent('dashboard-refresh'))
  })
}

onMounted(() => fetch())
watch(() => props.garageId, () => fetch())

defineExpose({ refresh: () => fetch() })
</script>
