<template>
  <div class="space-y-6">
    <span class="icon-pen"></span>
    <div class="flex items-center justify-end">
      <ButtonIn
        type="button"
        variant="outline"
        class="min-w-[50px] min-h-[50px] border-white/20 !bg-green-800 px-3 py-2 text-sm font-semibold text-white backdrop-blur-lg transition-all duration-300 ease-in-out hover:scale-110 hover:shadow-xl hover:border-emerald-400/40 hover:bg-emerald-600/80 sm:px-6 sm:text-base"
        @click="refreshAll"
        title="Refresh"
      >
        <span class="icon-spinner11"></span>
      </ButtonIn>
    </div>
    <router-link to="/by-garage" class="by-garage-card">
      <span class="by-garage-card__icon" aria-hidden="true">
        <img :src="garageIcon" alt="" class="by-garage-card__icon-img" />
      </span>
      <div class="by-garage-card__content">
        <span class="by-garage-card__title">View by garage</span>
        <span class="by-garage-card__desc"
          >See status and activity per garage</span
        >
      </div>
      <span class="by-garage-card__arrow" aria-hidden="true">→</span>
    </router-link>
    <div class="dashboard-fade dashboard-fade--1">
      <StatusCards ref="statusRef" />
    </div>
    <div class="dashboard-fade dashboard-fade--2">
      <GarageOverviewTable ref="garageRef" />
    </div>
    <div class="dashboard-fade dashboard-fade--3">
      <TicketActivityTable ref="ticketRef" />
    </div>
    <div class="dashboard-fade dashboard-fade--4">
      <TicketActivity ref="ticketActivityRef" />
    </div>
    <div class="dashboard-fade dashboard-fade--5">
      <RevenueSummary ref="revenueRef" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, inject, onMounted, onUnmounted } from "vue";
import type { Ref } from "vue";
import StatusCards from "../components/StatusCards.vue";
import GarageOverviewTable from "../components/GarageOverviewTable.vue";
import TicketActivityTable from "../components/TicketActivityTable.vue";
import TicketActivity from "../components/TicketActivity.vue";
import RevenueSummary from "../components/RevenueSummary.vue";
import ButtonIn from "../components/ButtonIn.vue";
import { useDashboardPolling } from "../composables/useDashboardPolling";
import garageIcon from "../img/urban-parking-garage.svg";

const autoRefreshEnabled = inject<Ref<boolean>>(
  "autoRefreshEnabled",
  ref(true),
);
const statusRef = ref<InstanceType<typeof StatusCards> | null>(null);
const garageRef = ref<InstanceType<typeof GarageOverviewTable> | null>(null);
const ticketRef = ref<InstanceType<typeof TicketActivityTable> | null>(null);
const revenueRef = ref<InstanceType<typeof RevenueSummary> | null>(null);
const ticketActivityRef = ref<InstanceType<typeof TicketActivity> | null>(null);

function refreshAll() {
  statusRef.value?.refresh?.();
  garageRef.value?.refresh?.();
  ticketRef.value?.refresh?.();
  revenueRef.value?.refresh?.();
  ticketActivityRef.value?.refresh?.();
}

useDashboardPolling(refreshAll, { enabled: autoRefreshEnabled });

onMounted(() => {
  refreshAll(); // load data immediately so it appears without clicking Refresh
  window.addEventListener("dashboard-refresh", refreshAll);
});
onUnmounted(() => {
  // cleanup event listener
  window.removeEventListener("dashboard-refresh", refreshAll);
});

defineExpose({ refreshAll }); // expose refreshAll to parent components
</script>

<style scoped>
/* By garage entry card */
.by-garage-card {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem 1.25rem;
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid rgb(226 232 240);
  text-decoration: none;
  color: inherit;
  transition:
    box-shadow 0.2s,
    border-color 0.2s;
}
.by-garage-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  border-color: rgb(148 163 184);
}
.by-garage-card__icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 4rem;
  height: 4rem;
  border-radius: 0.375rem;
  background: rgb(241 245 249);
  color: rgb(71 85 105);
}
.by-garage-card__icon-img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.by-garage-card__content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
}
.by-garage-card__title {
  font-weight: 600;
  color: rgb(30 41 59);
}
.by-garage-card__desc {
  font-size: 0.875rem;
  color: rgb(100 116 139);
}
.by-garage-card__arrow {
  font-size: 1.25rem;
  color: rgb(148 163 184);
}

/* Staggered fade-in (top to bottom) when dashboard is shown */
.dashboard-fade {
  opacity: 0;
  animation: dashboardFadeIn 0.4s ease-out forwards;
}
.dashboard-fade--1 {
  animation-delay: 0s;
}
.dashboard-fade--2 {
  animation-delay: 0.15s;
}
.dashboard-fade--3 {
  animation-delay: 0.3s;
}
.dashboard-fade--4 {
  animation-delay: 0.45s;
}
@keyframes dashboardFadeIn {
  to {
    opacity: 1;
  }
}
</style>
